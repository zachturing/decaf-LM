#include<iostream>
#include "mytest.h"
using namespace std;
int main(void)
{
    cout<<sum(1, 2)<<endl;
    return 0;
}

