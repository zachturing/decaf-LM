#ifndef _MYTEST_H_
#define _MYTEST_H_

int sum(int, int);

#endif
