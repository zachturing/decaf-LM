#ifndef _CMD_HANDLE_H
#define _CMD_HANDLE_H

void do_monitor_proc(Monitor* mon, const QDict* qdict);
void do_set_logfile1(Monitor *mon, const QDict *qdict);
void do_set_logfile2(Monitor *mon, const QDict *qdict);
void do_register_hooks(Monitor *mon);
void do_enable_keylogger_check( Monitor *mon, const QDict *qdict);
void do_disable_keylogger_check( Monitor *mon, const QDict *qdict);

#endif