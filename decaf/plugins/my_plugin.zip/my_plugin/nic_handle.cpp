#include <inttypes.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/queue.h>
#include <netinet/in.h>
#define __FAVOR_BSD
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#ifdef CONFIG_TCG_TAINT
#include "tainting/taintcheck_opt.h"
#endif

#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;

#include "DECAF_main.h"
#include "DECAF_callback.h"
#include "DECAF_callback_common.h"
#include "vmi_callback.h"
#include "utils/Output.h"
#include "DECAF_target.h"
#include "hookapi.h"
#include "shared/vmi_callback.h"
#include "vmi_c_wrapper.h"
#include "shared/tainting/taintcheck_opt.h"
#include "function_map.h"
#include "DECAF_types.h"
#include "config.h"


extern vector<string> vTargetFile;

//测试函数
void PrintInfo()
{
	cout<<"call PrintInfo."<<endl;
	for(vector<string>::iterator it = vTargetFile.begin(); it!= vTargetFile.end(); ++it)
	{
		cout<<it->c_str()<<endl;
	}

}

void tracing_nic_recv(DECAF_Callback_Params* params)
{
	DECAF_printf("tracing_nic_recv.\n");
}

void tracing_nic_send(DECAF_Callback_Params* params)
{
	DECAF_printf("do_nic_send_callback:\n");
	uint32_t addr = params->ns.addr;
	int size = params->ns.size;
	uint8_t * buf = params->ns.buf;
	uint32_t conn_id = 0;
	DECAF_printf("addr:%x\n", addr);
	DECAF_printf("buf:%x\n", buf);
	DECAF_printf("size: %d\n", size);
	if ((buf == NULL) || (size == 0))
		return;
	
#ifdef HOST_WORDS_BIGENDIAN
	DECAF_printf("HOST_WORDS_BIGENDIAN\n");
#else
	DECAF_printf("little endian\n");
#endif
	struct ip *iph = (struct ip *) (buf + 14);
	struct tcphdr *tcph = (struct tcphdr *) (buf + 34);
	struct udphdr *udph = (struct udphdr *) (buf + 34);
	//获取ip头部信息
	if (buf[12] != 0x08 || buf[13] != 0 || // Ignore non-IP packets
			(iph->ip_p != 6 && iph->ip_p != 17) ) // Ignore non TCP/UDP segments
	{
		DECAF_printf("the upper layer isn't IP protocol.\n");
		return;
	}

	DECAF_printf("the upper layer is IP protocol.\n");
	
	const char* ip_src = inet_ntoa(iph->ip_src);  //源IP地址
	const char* ip_dst = inet_ntoa(iph->ip_dst);  //目的IP地址
	DECAF_printf("%s --> %s\n", ip_src, ip_dst);
	/* TCP */
	if(6 == iph->ip_p)
	{
		DECAF_printf("The upper layer is TCP protocol.\n");
		
		uint32_t sport = ntohs(tcph->th_sport);		  //源端口号	
		uint32_t dport = ntohs(tcph->th_dport);	      //目的端口号
		DECAF_printf("%d --> %d\n", sport, dport);
		return;
	} 
	/* UDP */
	if(17 == iph->ip_p)
	{
		DECAF_printf("The upper layer is UDP protocol.\n");
		
		uint32_t sport = ntohs(udph->uh_sport);		  //源端口号	
		uint32_t dport = ntohs(udph->uh_dport);	      //目的端口号
		DECAF_printf("%d --> %d\n", sport, dport);
		return;
	}
}