#ifdef __cplusplus
extern "C"
{
#endif 

#include "DECAF_main.h"
#include "DECAF_callback.h"
#include "DECAF_callback_common.h"
#include "vmi_callback.h"
#include "utils/Output.h"
#include "DECAF_target.h"
#include "hookapi.h"
#include "shared/vmi_callback.h"
#include "vmi_c_wrapper.h"
#include "shared/tainting/taintcheck_opt.h"
#include "function_map.h"
#include "DECAF_types.h"
#include "config.h"

#ifdef __cplusplus
}
#endif

extern char targetname[512];

void do_monitor_proc(Monitor* mon, const QDict* qdict)
{
	if ((qdict != NULL) && (qdict_haskey(qdict, "procname"))) 
	{
		strncpy(targetname, qdict_get_str(qdict, "procname"), 512);
	}
	targetname[511] = '\0';
}

void do_set_logfile1(Monitor *mon, const QDict *qdict)
{
	const char *logfile_t = qdict_get_str(qdict, "logfile");
	DECAF_printf("%s 1\n", logfile_t);
}

void do_set_logfile2(Monitor *mon, const QDict *qdict)
{
	const char *logfile_t = qdict_get_str(qdict, "logfile");
	DECAF_printf("%s 2\n", logfile_t);
}

void do_register_hooks(Monitor *mon)
{
	DECAF_printf("do_register_hooks.fffff\n");
}

void do_enable_keylogger_check( Monitor *mon, const QDict *qdict)
{
	DECAF_printf("do_enable_keylogger_check.\n");
}

void do_disable_keylogger_check( Monitor *mon, const QDict *qdict)
{
	DECAF_printf("do_disable_keylogger_check.\n");
}

