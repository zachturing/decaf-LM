#ifdef _SUM_H_
#define _SUM_H_


#ifdef __cplusplus
extern "C"
{
#endif

int sum(int a, int b);

#ifdef __cplusplus
}
#endif

#endif
