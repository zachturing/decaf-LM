#define DEFINE_INSN_BEGIN
#define DEFINE_INSN_END
#define DEFINE_BLOCK_BEGIN
#define DEFINE_BLOCK_END
#define DECAF_HOME "/home/bert/DECAF/decaf"
#define PLUGIN_PATH "/home/bert/DECAF/decaf/plugins/behaviormon"
